from flask import Flask, render_template, request, redirect, url_for, flash
from flask_pymongo import PyMongo

app = Flask(__name__)
# MongoDB Configuration (you can adjust the URI or DB name)
app.config["MONGO_URI"] = "mongodb://localhost:27017/hospitalDB"
# Secret key is needed for flashing messages
app.config["SECRET_KEY"] = "your_secret_key_here" # Replace with a real secret key
mongo = PyMongo(app)

# Home Page
@app.route("/")
def index():
    return render_template("index.html")

# Doctor Details
@app.route("/doctordetails", methods=["GET", "POST"])
def doctordetails():
    if request.method == "POST":
        # Basic validation
        if not all([request.form.get("doctorName"), request.form.get("employeeID"), request.form.get("specialization")]):
            flash("Please fill out all required fields.", "error")
            return render_template("doctordetails.html")

        # A dictionary to hold the data from the form
        doctor_data = {
            "doctorName": request.form.get("doctorName"),
            "employeeID": request.form.get("employeeID"),
            "specialization": request.form.get("specialization"),
            "contactEmail": request.form.get("contactEmail"),
            "contactPhone": request.form.get("contactPhone")
        }
        # Insert the data into the 'doctors' collection in MongoDB
        mongo.db.doctors.insert_one(doctor_data)
        # Flash a success message and redirect to the same page (GET request)
        flash("Doctor details submitted successfully!", "success")
        return redirect(url_for("doctordetails"))
    return render_template("doctordetails.html")

# Patient Details
@app.route("/patientdetails", methods=["GET", "POST"])
def patientdetails():
    if request.method == "POST":
        if not all([request.form.get("patName"), request.form.get("patDOB"), request.form.get("patAddress"), request.form.get("admittingDoc")]):
            flash("Please fill out all required fields.", "error")
            return render_template("patientdetails.html")

        patient_data = {
            "patName": request.form.get("patName"),
            "patDOB": request.form.get("patDOB"),
            "patAddress": request.form.get("patAddress"),
            "admittingDoc": request.form.get("admittingDoc")
        }
        mongo.db.patients.insert_one(patient_data)
        flash("Patient details submitted successfully!", "success")
        return redirect(url_for("patientdetails"))
    return render_template("patientdetails.html")

# Medicine Details
@app.route("/medicinedetails", methods=["GET", "POST"])
def medicinedetails():
    if request.method == "POST":
        if not all([request.form.get("medName"), request.form.get("batch"), request.form.get("quantity"), request.form.get("expiry")]):
            flash("Please fill out all required fields.", "error")
            return render_template("medicinedetails.html")

        medicine_data = {
            "medName": request.form.get("medName"),
            "batch": request.form.get("batch"),
            "quantity": int(request.form.get("quantity")), # Convert to integer
            "expiry": request.form.get("expiry")
        }
        mongo.db.medicines.insert_one(medicine_data)
        flash("Medicine stock updated successfully!", "success")
        return redirect(url_for("medicinedetails"))
    return render_template("medicinedetails.html")

# Billing Details
@app.route("/billingdetails", methods=["GET", "POST"])
def billingdetails():
    if request.method == "POST":
        if not all([request.form.get("billID"), request.form.get("patientID"), request.form.get("amount"), request.form.get("date")]):
            flash("Please fill out all required fields.", "error")
            return render_template("billingdetails.html")

        billing_data = {
            "billID": request.form.get("billID"),
            "patientID": request.form.get("patientID"),
            "amount": float(request.form.get("amount")), # Convert to float
            "date": request.form.get("date")
        }
        mongo.db.billing.insert_one(billing_data)
        flash("Billing details submitted successfully!", "success")
        return redirect(url_for("billingdetails"))
    return render_template("billingdetails.html")

if __name__ == "__main__":
    app.run(debug=True)
